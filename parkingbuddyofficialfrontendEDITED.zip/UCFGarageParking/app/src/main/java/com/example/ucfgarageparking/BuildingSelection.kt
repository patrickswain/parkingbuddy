package com.example.ucfgarageparking

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_building_selection.*
import kotlinx.android.synthetic.main.content_main.*
import android.widget.ListView as AndroidWidgetListView

class BuildingSelection : AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_building_selection)

        // Create an ArrayAdapter
        val adapter = ArrayAdapter.createFromResource(this,
            R.array.building_list, android.R.layout.simple_spinner_item)
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        // Apply the adapter to the spinner
        spinner.adapter = adapter

        distanceButton.setOnClickListener{
            when {
                spinner.selectedItem.equals("Biological Sciences Building BIO") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Business Administration 1 BA1") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Business Administration 2 BA2") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Chemistry Building CHEM") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Classroom Building 1 CB1") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Classroom Building 2 CB2") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Education Complex and Gym EC") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Engineering 1 ENG1") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Engineering 2 ENG2") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Harris Corporation Engineering HEC") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Health and Public Affairs 1 HPA1") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Health and Public Affairs 2 HPA2") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Mathematical Science Building MSB") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Nicholson School of Communication NSC") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Psychology Building PSY") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Student Union SU") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Teaching Academy TA") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Trevor Colbourn Hall TCH") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
                spinner.selectedItem.equals("Visual Arts Building VAB") -> Toast.makeText(this, "gararge: " + "distance: " + "availbility: ", Toast.LENGTH_LONG).show()
            }
        }
    }
}